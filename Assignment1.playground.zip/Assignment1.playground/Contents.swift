/*:
 # CSCI 321/521 Assignment 1
 ## Part B: Swift Foundations
 
 Welcome to the Swift Foundations playground! Complete each exercise below.
 Your code should compile and run without errors.
 
 **Student Name: Alexander Cumbo**
 **Z-ID: z1964909**
 **Partner Name (if applicable): Sathyan Asokan Geethpriya**
 **Partner Z-ID (if applicable): z1976271**
 
 ---
 */

import Foundation

/*:
 ## Exercise 1: Variables and Constants (8 points)
 
 ### 1a) App Name and User Count
 Declare a constant for your app's name and a variable for the current user count.
 Print both values.
 */

// Your code for 1a here:

let appName = "BizInsight KPI Dashboard"

var userCount = 2

print(appName)
print(userCount)


/*:
 ### 1b) Type Inference
 Create variables of type `Int`, `Double`, `String`, and `Bool` with explicit types.
 Then demonstrate type inference by declaring equivalent variables without explicit types.
 */

// Your code for 1b here:
// With explicit types:

var expInt: Int
var expDouble: Double
var expString: String = "I'm mad scientist so cool."
var expBool: Bool

// With type inference:

var infInt = 42
var infDouble = 4.2
var infString = "Hello, World!"
var infBool = true

/*:
 ### 1c) String Interpolation
 Use string interpolation to create a sentence using at least 3 of your variables.
 */

// Your code for 1c here:

print("\(infString) \(expString) Please enjoy using \(appName)")


/*:
 ---
 ## Exercise 2: Optionals (12 points)
 
 ### 2d) If-Let Unwrapping
 Declare an optional `String` called `userNickname`. Safely unwrap it using `if-let`
 and print either the nickname or "No nickname set".
 */

// Your code for 2d here:

var userNickname: String?

if let nickname = userNickname {
    print(nickname)
} else {
    print("No nickname set")
}


/*:
 ### 2e) Guard-Let Function
 Use `guard-let` to create a function `validateEmail(_ email: String?) -> Bool`
 that returns `false` if the email is nil or empty.
 */

// Your code for 2e here:

func validateEmail(_ email: String?) -> Bool {
    guard let email = email, !email.isEmpty else {
        return false
    }
    return true
}


/*:
 ### 2f) Nil Coalescing
 Demonstrate the nil coalescing operator (`??`) by providing a default value
 for an optional integer representing a user's age.
 */

// Your code for 2f here:

let optionalAge : Int? = nil

let age = optionalAge ?? 18

/*:
 ### 2g) When to Use Each Approach
 Explain in a comment when you would use `if-let` vs `guard-let` vs nil coalescing.
 */

/*
 Your explanation for 2g here:
 
 if-let: If you want to do something extra in case of value or vice versa.
 
 
 guard-let: If you want to ensure something is true before continuing
 
 
 nil coalescing (??): If you want to prepare a default value.
 
 
 */


/*:
 ---
 ## Exercise 3: Collections (10 points)
 
 ### 3h) Arrays
 Create an array of at least 5 items related to your app concept
 (e.g., recipe names, city names, task titles).
 */

// Your code for 3h here:

var arr = ["Company A", "Company B", "Company C", "Company D", "Company E"]


/*:
 ### 3i) Dictionaries
 Create a dictionary that maps `String` keys to values appropriate for your app
 (e.g., `["category": "Desserts"]`).
 */

// Your code for 3i here:

var revenue = [
    "Company A": 123456789,
    "Company B": 987654321,
    "Company C": 123890567,
    "Company D": 789456123,
    "Company E": 456213789
]


/*:
 ### 3j) Modifying Collections
 Demonstrate adding, removing, and accessing elements from both your array and dictionary.
 */

// Your code for 3j here:
// Make mutable copies if needed, then demonstrate:

// Adding to array:
arr.append("Company F")     //Appends to end of array

// Removing from array:
arr.removeLast()            //Remove from end of array

// Accessing array element:
print(arr[2])               //Prints 3rd element

// Adding to dictionary:
revenue["Company F"] = 456789123    //Adds Company F with initialized value to dictionary

// Removing from dictionary:
revenue.removeValue(forKey: "Company F")    //Removes Company F key

// Accessing dictionary value:
var cRev: Int = revenue["Company C"] ?? 0    //0 default value in order to print without error or warning
print(cRev)


/*:
 ### 3k) Sets
 Create a `Set` and demonstrate how it differs from an `Array` by adding duplicate values.
 */

// Your code for 3k here:

var numbers: Set = [1, 2, 3, 4, 5, 6]

print(numbers)

numbers.insert(2)    //Will not add because already exists in set
numbers.insert(7)    //Will add value because not already in set
numbers.insert(6)    //Will not add because already exists in set

print(numbers)


/*:
 ---
 ## Exercise 4: Control Flow (10 points)
 
 ### 4l) For-In Loop with Index
 Write a `for-in` loop that iterates over your array from Exercise 3
 and prints each item with its index.
 */

// Your code for 4l here:

for (index, company) in arr.enumerated() {
    print("Index: \(index) Value: \(company)")
}


/*:
 ### 4m) Switch Statement
 Write a `switch` statement that takes a `String` representing a user action
 (e.g., "view", "edit", "delete") and prints an appropriate message for each case.
 Include a default case.
 */

// Your code for 4m here:

let userAction = "view"

switch userAction {
case "view":
    print("Viewing")
case "edit":
    print("Editing")
case "delete":
    print("Deleting")
default:
    print("Unkown action")
}


/*:
 ### 4n) While Loop
 Write a `while` loop that simulates loading data, counting from 1 to 5
 and printing "Loading... X%" where X increases by 20 each iteration.
 */

// Your code for 4n here:

var count = 1

while count <= 5 {
    let percent = count * 20
    print("Loading... \(percent)%")
    
    count += 1
}


/*:
 ---
 ## Exercise 5: Functions and Closures (10 points)
 
 ### 5o) Function with Default Parameter
 Write a function `greetUser(name: String, timeOfDay: String = "day")`
 that returns a personalized greeting string.
 */

// Your code for 5o here:


// Test your function:



/*:
 ### 5p) Calculate Discount Function
 Write a function `calculateDiscount(price: Double, percentage: Int) -> Double`
 that returns the discounted price.
 */

// Your code for 5p here:

func calculateDiscount(price: Double, percentage: Int) -> Double {
    
    let discount = price * (Double(percentage) / 100)   //Double casting
    
    return price - discount
}


// Test your function:

let perc: Int = 10
let cost: Double = 100

var finalPrice: Double = calculateDiscount(price: cost, percentage: perc)

print(finalPrice)

/*:
 ### 5q) Map with Closure
 Use the `map` function with a closure to transform your array from Exercise 3
 (e.g., convert all strings to uppercase).
 */

// Your code for 5q here:

let upperArr = arr.map { (company: String) -> String in   //Converts all indexes to lowercase
    return company.uppercased()
}

print(upperArr)

/*:
 ### 5r) Filter with Closure
 Use the `filter` function with a closure to filter your array
 based on some condition (e.g., items containing a specific letter).
 */

// Your code for 5r here:

let iLikeC = arr.filter { company in        //Filters and return strings containing "C"
    return company.contains("C")
}

print(iLikeC)

/*:
 ---
 ## 🎉 Congratulations!
 
 You've completed the Swift Foundations exercises. Make sure to:
 1. Review your code for any errors
 2. Add comments where helpful
 3. Ensure everything compiles and runs
 4. Zip this playground for submission
 */
