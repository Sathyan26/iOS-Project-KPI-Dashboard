import SwiftUI

/// Screen 1 – Home / KPI Overview
/// Displays the top summary KPI cards using sample data.
struct DashboardView: View {

    // Only show KPIs that are enabled (mirrors Settings checkboxes)
    private var enabledKPIs: [KPI] {
        SampleData.kpis.filter { $0.isEnabled }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Screen title block
                VStack(alignment: .leading, spacing: 2) {
                    Text("Dashboard")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Text("[Screen 1 - Home / KPI Overview]")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal)
                .padding(.top, 8)

                Divider()
                    .padding(.horizontal)

                // Section header
                SectionHeaderView(title: "Top Summary Cards:")
                    .padding(.horizontal)

                // KPI cards — VStack of individual cards
                VStack(spacing: 12) {
                    ForEach(enabledKPIs) { kpi in
                        KPIStatCard(kpi: kpi)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 16)
            }
        }
        .background(Color(.systemGroupedBackground))
    }
}

#Preview {
    DashboardView()
}
