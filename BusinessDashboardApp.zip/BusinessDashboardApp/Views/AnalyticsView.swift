import SwiftUI
import Charts

/// Screen 2 – Metric Detail / Analytics
/// Shows a segmented control, a time-series line chart, and an insights panel.
struct AnalyticsView: View {

    // Metrics available in the segmented control
    private let metrics = ["Sales", "Expenses", "Profit", "Products"]
    @State private var selectedMetric = "Sales"

    private let data = SampleData.salesPoints

    // Computed max for Y axis ceiling
    private var yMax: Double {
        (data.map(\.amount).max() ?? 8000) * 1.15
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Back button + title (static; navigation wired in A4)
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color(.systemGray4), lineWidth: 1)
                            .frame(width: 36, height: 36)
                        Image(systemName: "chevron.left")
                            .foregroundStyle(.primary)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Sales Analytics")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("[Screen 2 - Metric Detail / Analytics]")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal)
                .padding(.top, 8)

                Divider().padding(.horizontal)

                // Segmented control section
                SectionHeaderView(title: "Segmented Control (Switch Metrics):")
                    .padding(.horizontal)

                // Custom pill-style segmented control
                HStack(spacing: 0) {
                    ForEach(metrics, id: \.self) { metric in
                        Button(action: { selectedMetric = metric }) {
                            Text(metric)
                                .font(.subheadline)
                                .fontWeight(selectedMetric == metric ? .semibold : .regular)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(selectedMetric == metric ? Color.blue : Color.clear)
                                .foregroundStyle(selectedMetric == metric ? .white : .primary)
                        }
                    }
                }
                .background(Color(.systemGray6))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding(.horizontal)

                // Large chart section
                SectionHeaderView(title: "Large Chart (Time Series):")
                    .padding(.horizontal)

                // Chart card
                GroupBox {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Sales Overview")
                            .font(.headline)
                        Text("Last 8 days")
                            .font(.caption)
                            .foregroundStyle(.secondary)

                        // SwiftUI Charts line chart
                        Chart(data) { point in
                            LineMark(
                                x: .value("Date", point.date),
                                y: .value("Amount", point.amount)
                            )
                            .foregroundStyle(Color.blue)
                            .interpolationMethod(.catmullRom)

                            PointMark(
                                x: .value("Date", point.date),
                                y: .value("Amount", point.amount)
                            )
                            .foregroundStyle(Color.blue)
                            .symbolSize(40)
                        }
                        .chartYScale(domain: 0...yMax)
                        .chartYAxis {
                            AxisMarks(values: [0, 2000, 4000, 6000, 8000]) { val in
                                AxisGridLine()
                                AxisValueLabel {
                                    if let v = val.as(Double.self) {
                                        Text("\(Int(v/1000))k")
                                            .font(.caption2)
                                    }
                                }
                            }
                        }
                        .chartXAxis {
                            AxisMarks { val in
                                AxisValueLabel()
                                    .font(.caption2)
                            }
                        }
                        .frame(height: 200)
                        .padding(.top, 8)
                    }
                }
                .padding(.horizontal)

                // Insights section
                SectionHeaderView(title: "Text Area (Insights):")
                    .padding(.horizontal)

                // Insights panel
                GroupBox {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 6) {
                            Image(systemName: "chart.bar.fill")
                                .foregroundStyle(.orange)
                            Text("Insights")
                                .font(.headline)
                        }
                        Divider()
                        InsightRow(text: "Sales increased **15%** compared to last week")
                        InsightRow(text: "Peak sales day: **Saturday ($7,500)**")
                        InsightRow(text: "Lowest sales day: **Tuesday ($3,900)**")
                        InsightRow(text: "7-day average: **$5,737**")
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 16)
            }
        }
        .background(Color(.systemGroupedBackground))
    }
}

#Preview {
    AnalyticsView()
}
