import SwiftUI

/// Additional Screen – Customer List
/// Displays total customer count and a scrollable list of CustomerRowCards.
struct CustomersView: View {

    private let customers = SampleData.customers

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Back button + title
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color(.systemGray4), lineWidth: 1)
                            .frame(width: 36, height: 36)
                        Image(systemName: "chevron.left")
                            .foregroundStyle(.primary)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Customers")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("[Additional Screen - Customer List]")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal)
                .padding(.top, 8)

                Divider().padding(.horizontal)

                // Total customers summary banner
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Total Customers")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text("1,249")
                            .font(.title)
                            .fontWeight(.bold)
                    }
                    Spacer()
                    Image(systemName: "person.2.fill")
                        .font(.largeTitle)
                        .foregroundStyle(Color(.systemGray3))
                }
                .padding()
                .background(Color.blue.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .padding(.horizontal)

                // Customer list section
                SectionHeaderView(title: "Customer List:")
                    .padding(.horizontal)

                // List of customer cards — uses ForEach to satisfy List/ForEach requirement
                VStack(spacing: 12) {
                    ForEach(customers) { customer in
                        CustomerRowCard(customer: customer)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 16)
            }
        }
        .background(Color(.systemGroupedBackground))
    }
}

#Preview {
    CustomersView()
}
