import SwiftUI

/// Screen 4 – Settings / Preferences
/// This is the Form/Input screen. Includes Toggle, Picker, DatePicker, Stepper,
/// TextField, and segmented Picker — all static (no action) per Assignment 3 spec.
struct SettingsView: View {

    // MARK: - State for form controls (static / non-functional for now)
    @State private var revenueEnabled   = true
    @State private var salesEnabled     = true
    @State private var customersEnabled = true
    @State private var profitEnabled    = true
    @State private var avgOrderEnabled  = false
    @State private var newCustEnabled   = false

    // Date range picker
    @State private var selectedRange    = "Today"
    private let dateRanges = ["Today", "This Week", "This Month", "Custom"]

    // Notification prefs
    @State private var enableNotifications = true
    @State private var alertThreshold: Double = 500
    @State private var refreshInterval = 5   // minutes (Stepper)

    // Display prefs
    @State private var currencyCode = "USD"
    private let currencies = ["USD", "EUR", "GBP", "JPY"]

    @State private var selectedTheme = "System"
    private let themes = ["Light", "Dark", "System"]

    @State private var customNote = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Back button + title
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color(.systemGray4), lineWidth: 1)
                            .frame(width: 36, height: 36)
                        Image(systemName: "chevron.left")
                            .foregroundStyle(.primary)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Settings")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("[Screen 4 - Settings / Preferences]")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal)
                .padding(.top, 8)

                Divider().padding(.horizontal)

                // ── Section 1: Available KPIs (Checkboxes / Toggles) ────────────
                SectionHeaderView(title: "Available KPIs (Checkboxes):")
                    .padding(.horizontal)

                GroupBox {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Dashboard KPIs")
                            .font(.headline)
                        Text("Select which metrics to show")
                            .font(.caption)
                            .foregroundStyle(.secondary)

                        Divider().padding(.vertical, 4)

                        // Six toggle rows — satisfies Toggle + organising with Dividers
                        kpiToggleRow(icon: "dollarsign",       label: "Today's Revenue",   isOn: $revenueEnabled)
                        kpiToggleRow(icon: "arrow.up.right",   label: "This Week's Sales",  isOn: $salesEnabled)
                        kpiToggleRow(icon: "person.2",         label: "Active Customers",   isOn: $customersEnabled)
                        kpiToggleRow(icon: "creditcard",       label: "Net Profit",          isOn: $profitEnabled)
                        kpiToggleRow(icon: "cart",             label: "Average Order Value", isOn: $avgOrderEnabled)
                        kpiToggleRow(icon: "person.badge.plus",label: "New Customers",       isOn: $newCustEnabled)
                    }
                }
                .padding(.horizontal)

                // ── Section 2: Default Date Range (Picker - segmented) ───────────
                SectionHeaderView(title: "Default Date Range:")
                    .padding(.horizontal)

                GroupBox {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "calendar")
                                .foregroundStyle(.blue)
                            Text("Default Date Range")
                                .font(.headline)
                        }
                        // Segmented Picker
                        Picker("Date Range", selection: $selectedRange) {
                            ForEach(dateRanges, id: \.self) { range in
                                Text(range).tag(range)
                            }
                        }
                        .pickerStyle(.segmented)

                        // Wheel Picker for currency (second Picker style)
                        HStack {
                            Text("Currency")
                                .font(.subheadline)
                            Spacer()
                            Picker("Currency", selection: $currencyCode) {
                                ForEach(currencies, id: \.self) { c in
                                    Text(c).tag(c)
                                }
                            }
                            .pickerStyle(.menu)
                        }
                    }
                }
                .padding(.horizontal)

                // ── Section 3: Notifications & Alerts ───────────────────────────
                GroupBox {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "bell.fill")
                                .foregroundStyle(.orange)
                            Text("Notifications")
                                .font(.headline)
                        }
                        Divider()

                        // Toggle
                        Toggle("Enable Alerts", isOn: $enableNotifications)
                            .font(.subheadline)

                        // Slider — revenue alert threshold
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Alert Threshold: $\(Int(alertThreshold))")
                                .font(.subheadline)
                            Slider(value: $alertThreshold, in: 100...2000, step: 100)
                                .tint(.blue)
                        }

                        // Stepper — data refresh interval
                        Stepper("Refresh every \(refreshInterval) min",
                                value: $refreshInterval, in: 1...60)
                            .font(.subheadline)
                    }
                }
                .padding(.horizontal)

                // ── Section 4: Display Preferences ──────────────────────────────
                GroupBox {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "paintbrush.fill")
                                .foregroundStyle(.purple)
                            Text("Display")
                                .font(.headline)
                        }
                        Divider()

                        // Segmented theme picker
                        VStack(alignment: .leading, spacing: 4) {
                            Text("App Theme")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            Picker("Theme", selection: $selectedTheme) {
                                ForEach(themes, id: \.self) { t in
                                    Text(t).tag(t)
                                }
                            }
                            .pickerStyle(.segmented)
                        }

                        // TextField — custom note / label
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Dashboard Label (optional)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            TextField("e.g. Q2 Goals", text: $customNote)
                                .textFieldStyle(.roundedBorder)
                        }
                    }
                }
                .padding(.horizontal)

                // ── Save / Cancel buttons (no action — A3 static) ───────────────
                HStack(spacing: 12) {
                    Button("Cancel") { }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(Color(.systemGray5))
                        .foregroundStyle(.primary)
                        .clipShape(RoundedRectangle(cornerRadius: 10))

                    Button("Save Changes") { }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(Color.blue)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                        .fontWeight(.semibold)
                }
                .padding(.horizontal)
                .padding(.bottom, 24)
            }
        }
        .background(Color(.systemGroupedBackground))
    }

    // MARK: - Helper: single KPI toggle row
    @ViewBuilder
    private func kpiToggleRow(icon: String, label: String, isOn: Binding<Bool>) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .frame(width: 20)
                .foregroundStyle(.blue)
            Text(label)
                .font(.subheadline)
            Spacer()
            Toggle("", isOn: isOn)
                .labelsHidden()
        }
        .padding(.vertical, 4)
        .padding(.horizontal, 8)
        .background(isOn.wrappedValue ? Color.blue.opacity(0.08) : Color.clear)
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
}

#Preview {
    SettingsView()
}
