import Foundation

// All static sample data for the app
struct SampleData {

    // MARK: - KPI Cards
    static let kpis: [KPI] = [
        KPI(title: "Today's Revenue",   value: "$12,580", change: "+12.5% vs yesterday", isPositive: true,  icon: "dollarsign"),
        KPI(title: "This Week's Sales", value: "$45,230", change: "+15% vs last week",   isPositive: true,  icon: "arrow.up.right"),
        KPI(title: "Active Customers",  value: "1,249",   change: "+34 this week",        isPositive: true,  icon: "person.2"),
        KPI(title: "Net Profit",        value: "$8,940",  change: "This week",            isPositive: true,  icon: "creditcard"),
        KPI(title: "Avg Order Value",   value: "$36.20",  change: "+2.1% vs last week",   isPositive: true,  icon: "cart"),
        KPI(title: "New Customers",     value: "87",      change: "-5 vs last week",      isPositive: false, icon: "person.badge.plus", isEnabled: false)
    ]

    // MARK: - Customers
    static let customers: [Customer] = [
        Customer(name: "Sarah Johnson", orders: 24, totalSpent: 1240, status: .active),
        Customer(name: "Mike Chen",     orders: 18, totalSpent: 890,  status: .active),
        Customer(name: "Emily Davis",   orders: 31, totalSpent: 2100, status: .vip),
        Customer(name: "James Wilson",  orders: 9,  totalSpent: 430,  status: .active),
        Customer(name: "Olivia Brown",  orders: 45, totalSpent: 3780, status: .vip),
        Customer(name: "Liam Martinez", orders: 2,  totalSpent: 95,   status: .inactive)
    ]

    // MARK: - Sales Chart (last 8 days)
    static let salesPoints: [SalesPoint] = [
        SalesPoint(date: "Feb 17", amount: 4200),
        SalesPoint(date: "Feb 18", amount: 3900),
        SalesPoint(date: "Feb 19", amount: 5100),
        SalesPoint(date: "Feb 20", amount: 4600),
        SalesPoint(date: "Feb 21", amount: 6200),
        SalesPoint(date: "Feb 22", amount: 7600),
        SalesPoint(date: "Feb 23", amount: 6900),
        SalesPoint(date: "Feb 24", amount: 7400)
    ]
}
