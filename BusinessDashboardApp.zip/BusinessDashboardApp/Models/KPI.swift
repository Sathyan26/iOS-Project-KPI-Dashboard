import Foundation

// Represents a single KPI metric card on the dashboard
struct KPI: Identifiable {
    let id = UUID()
    let title: String
    let value: String
    let change: String
    let isPositive: Bool
    let icon: String // SF Symbol name
    var isEnabled: Bool = true
}
