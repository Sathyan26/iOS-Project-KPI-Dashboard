import Foundation

// Status badge for each customer
enum CustomerStatus: String {
    case active = "Active"
    case vip = "VIP"
    case inactive = "Inactive"
}

// Represents a single customer record
struct Customer: Identifiable {
    let id = UUID()
    let name: String
    let orders: Int
    let totalSpent: Double
    let status: CustomerStatus
}
