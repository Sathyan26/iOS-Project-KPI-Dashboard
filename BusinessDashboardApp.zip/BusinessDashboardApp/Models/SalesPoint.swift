import Foundation

// A single data point for the sales chart
struct SalesPoint: Identifiable {
    let id = UUID()
    let date: String   // e.g. "Feb 17"
    let amount: Double // e.g. 4200
}
