import SwiftUI

@main
struct BusinessDashboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
