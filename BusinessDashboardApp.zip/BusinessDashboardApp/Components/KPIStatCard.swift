import SwiftUI

/// Reusable KPI summary card shown on the Dashboard screen.
struct KPIStatCard: View {
    let kpi: KPI

    var body: some View {
        // ZStack not needed here but outer HStack + VStack satisfies layout requirement
        VStack(alignment: .leading, spacing: 6) {
            // Title row with icon
            HStack {
                Text(kpi.title)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Spacer()
                Image(systemName: kpi.icon)
                    .font(.title2)
                    .foregroundStyle(.secondary)
            }

            // Big value
            Text(kpi.value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundStyle(.primary)

            // Change indicator
            HStack(spacing: 4) {
                if kpi.isPositive {
                    Image(systemName: "arrow.up.right")
                        .font(.caption)
                        .foregroundStyle(.green)
                }
                Text(kpi.change)
                    .font(.caption)
                    .foregroundStyle(kpi.isPositive ? .green : .secondary)
            }

            // Tap for details only on revenue / sales cards
            if kpi.title == "Today's Revenue" || kpi.title == "This Week's Sales" {
                HStack {
                    Spacer()
                    Text("Tap for details →")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding()
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
    }
}

#Preview {
    KPIStatCard(kpi: SampleData.kpis[0])
        .padding()
}
