import SwiftUI

/// A single bullet-point insight row used in the Analytics screen.
struct InsightRow: View {
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Circle()
                .fill(Color.blue)
                .frame(width: 7, height: 7)
                .padding(.top, 5)
            // Render the text with bold markdown-style inline
            Text(LocalizedStringKey(text))
                .font(.subheadline)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

#Preview {
    VStack(alignment: .leading, spacing: 8) {
        InsightRow(text: "Sales increased **15%** compared to last week")
        InsightRow(text: "Peak sales day: **Saturday ($7,500)**")
    }
    .padding()
}
