import SwiftUI

/// Reusable section header with an arrow indicator, matching wireframe style.
struct SectionHeaderView: View {
    let title: String

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: "arrow.right")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer()
        }
    }
}

#Preview {
    SectionHeaderView(title: "Top Summary Cards:")
        .padding()
}
