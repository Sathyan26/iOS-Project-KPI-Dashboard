import SwiftUI

/// Reusable card for a single customer in the Customers list.
struct CustomerRowCard: View {
    let customer: Customer

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(customer.name)
                        .font(.headline)
                    Text("\(customer.orders) orders")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                // Status badge
                statusBadge
            }

            Text("$\(String(format: "%.0f", customer.totalSpent))")
                .font(.title3)
                .fontWeight(.semibold)
            Text("Total spent")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
    }

    // Badge color varies by status
    @ViewBuilder
    private var statusBadge: some View {
        let color: Color = {
            switch customer.status {
            case .active:   return .blue
            case .vip:      return Color(red: 0.8, green: 0.6, blue: 0)
            case .inactive: return .gray
            }
        }()

        Text(customer.status.rawValue)
            .font(.caption)
            .fontWeight(.medium)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .foregroundStyle(color)
            .overlay(
                RoundedRectangle(cornerRadius: 6)
                    .stroke(color, lineWidth: 1)
            )
    }
}

#Preview {
    VStack(spacing: 12) {
        ForEach(SampleData.customers) { c in
            CustomerRowCard(customer: c)
        }
    }
    .padding()
}
