import SwiftUI

/// Root content view — hosts the TabView that wires all 4 screens together.
/// Navigation between tabs is intentionally static (Assignment 3).
/// Full NavigationStack wiring will be added in Assignment 4.
struct ContentView: View {
    var body: some View {
        TabView {
            // Tab 1 – Dashboard (List/Browse screen)
            DashboardView()
                .tabItem {
                    Label("Dashboard", systemImage: "arrow.up.right")
                }

            // Tab 2 – Analytics (Detail screen)
            AnalyticsView()
                .tabItem {
                    Label("Analytics", systemImage: "chart.line.uptrend.xyaxis")
                }

            // Tab 3 – Customers (Additional screen)
            CustomersView()
                .tabItem {
                    Label("Customers", systemImage: "person.2")
                }

            // Tab 4 – Settings (Form/Input screen)
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "square")
                }
        }
        .tint(.blue) // matches wireframe's active-tab blue
    }
}

#Preview {
    ContentView()
}
