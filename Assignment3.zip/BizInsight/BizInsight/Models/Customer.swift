//
//  Customer.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//

import Foundation

struct Customer: Identifiable {
    let id = UUID()
    let name: String
    let orders: Int
    let totalSpent: Double
}
