//
//  TransactionRowView.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//

import SwiftUI

struct TransactionRowView: View {
    var transaction: Transaction

    var body: some View {

        ZStack { //Background color

            RoundedRectangle(cornerRadius: 12)
                .fill(Color.gray.opacity(0.1))

            HStack(spacing: 12) {
                
                //Icon

                Image(systemName: transaction.isRevenue ? "arrow.up.circle.fill" : "arrow.down.circle.fill")
                    .foregroundStyle(transaction.isRevenue ? .green : .red)
                    .font(.title2)

                //Category + name
                
                VStack(alignment: .leading) {
                    Text(transaction.category.rawValue.capitalized)
                        .font(.headline)

                    Text(transaction.customer ?? "")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()
                
                //Transaction amount

                Text("$\(transaction.amount, specifier: "%.2f")")
                    .bold()
            }
            .padding(.horizontal)
            .padding(.vertical, 10)
        }
        .padding(.horizontal)
    }
}

#Preview {
    TransactionRowView(transaction: Transaction.sampleData[0])
}
