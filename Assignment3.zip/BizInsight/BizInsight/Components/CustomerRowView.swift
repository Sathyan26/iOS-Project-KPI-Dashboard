//
//  CustomerRowView.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//

import SwiftUI

struct CustomerRowView: View {
    let customer: Customer

    var body: some View {
        HStack(spacing: 12) {

            // Icon
            Image(systemName: "person.circle.fill")
                .font(.largeTitle)
                .foregroundStyle(.black)

            // Name + orders
            VStack(alignment: .leading) {
                Text(customer.name)
                    .font(.headline)

                Text("\(customer.orders) orders")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            // Total spent
            Text("$\(customer.totalSpent, specifier: "%.2f")")
                .bold()
        }
        .padding(.vertical, 6)
    }
}

#Preview {
    CustomerRowView(customer: Customer(name: "Alex", orders: 5, totalSpent: 1200))
}
