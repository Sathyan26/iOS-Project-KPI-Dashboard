//
//  AnalyticsView.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//

import SwiftUI

struct AnalyticsView: View {

    let transaction = Transaction.sampleData[0]

    var body: some View {
        ScrollView {

            VStack(alignment: .leading, spacing: 20) {

                Image(systemName: "chart.bar.xaxis")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 120)
                    .padding()

                Text("Analytics Detail")
                    .font(.largeTitle)
                    .bold()
                    .padding(.horizontal)

                //Transaction Overview Box
                
                GroupBox(label: Label("Transaction Overview", systemImage: "info.circle")) {

                    VStack(alignment: .leading, spacing: 10) {
                        Spacer().frame(height: 2)

                        Text("Category: \(transaction.category.rawValue.capitalized)")
                        Text("Type: \(transaction.isRevenue ? "Revenue" : "Expense")")
                        HStack {
                            Text("Amount:")

                            Text("$\(transaction.amount, specifier: "%.2f")")
                                .bold()
                                .foregroundStyle(transaction.isRevenue ? .green : .red)
                        }
                        Text("Channel: \(transaction.channel.rawValue.capitalized)")
                        Text("Customer: \(transaction.customer ?? "None")")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal)
                
                //Transaction Summary Box

                GroupBox(label: Label("Transaction Summary", systemImage: "doc.text")) {

                    VStack(alignment: .leading, spacing: 10) {
                        Spacer().frame(height: 2)
                        
                        HStack {
                            Text("Amount:")

                            Text("$\(transaction.amount, specifier: "%.2f")")
                                .bold()
                                .foregroundStyle(transaction.isRevenue ? .green : .red)
                        }
                        
                        Text("Type: \(transaction.isRevenue ? "Revenue" : "Expense")")

                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.horizontal)
                
                //More Info button to show transaction ID, date, online/offline and category

                DisclosureGroup("More Info") {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("ID: \(transaction.id.uuidString)")
                        Text("Date: \(transaction.date.formatted())")
                        Text("Channel: \(transaction.channel.rawValue.capitalized)")
                        Text("Category: \(transaction.category.rawValue.capitalized)")
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }
                .padding(.horizontal)
            }
        }
    }
}

#Preview {
    AnalyticsView()
}
