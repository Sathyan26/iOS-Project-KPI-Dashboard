//
//  TransactionFormView.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//
import SwiftUI

struct TransactionFormView: View {

    @State private var customer: String = ""
    @State private var amountText: String = ""
    @State private var selectedCategory: CategoryType = .food
    @State private var selectedType: TransactionType = .sale
    @State private var isOnline: Bool = true
    @State private var date: Date = Date()

    var body: some View {
        Form {
            
            //Basic Info Box to input name, category, and sale/expense
            
            Section("Basic Info") {

                TextField("Name", text: $customer)

                Picker("Category", selection: $selectedCategory) {
                    ForEach(CategoryType.allCases, id: \.self) { category in
                        Text(category.rawValue.capitalized)
                    }
                }

                Picker("Type", selection: $selectedType) {
                    Text("Sale").tag(TransactionType.sale)
                    Text("Expense").tag(TransactionType.expense)
                }
                .pickerStyle(.segmented)
            }
            
            //Details Box to input date, online transaction or not, and amount

            Section("Details") {

                DatePicker("Date", selection: $date, displayedComponents: .date)

                Toggle("Online Transaction", isOn: $isOnline)

                HStack {
                    Text("Amount:")
                    TextField("0.00", text: $amountText)
                        .keyboardType(.decimalPad)
                        .multilineTextAlignment(.trailing)
                }
            }

            Section {

                Button("Save") {
                }

                Button("Cancel") {
                }
                .foregroundStyle(.red)
            }
        }
    }
}

#Preview {
    TransactionFormView()
}
