//
//  CustomersView.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//
import SwiftUI

struct CustomersView: View {

    //Defines Customers and manages its data
    
    var customers: [Customer] {
        
        let revenueTransactions = Transaction.sampleData.filter { $0.isRevenue }

        let grouped = Dictionary(grouping: revenueTransactions) { transaction in
            transaction.customer ?? "Unknown"
        }

        return grouped.map { (name, transactions) in
            
            let orders = transactions.count
            
            let totalSpent = transactions.reduce(0) { sum, transaction in
                sum + transaction.amount
            }

            return Customer(
                name: name,
                orders: orders,
                totalSpent: totalSpent
            )
        }
        .sorted { $0.totalSpent > $1.totalSpent }
    }
    
    //Lists Customer Objects

    var body: some View {
        NavigationStack {

            List(customers) { customer in
                CustomerRowView(customer: customer)
            }
            .navigationTitle("Customers")
        }
    }
}

#Preview {
    CustomersView()
}
