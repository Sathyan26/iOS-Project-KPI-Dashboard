//
//  DashboardView.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//

import SwiftUI

struct DashboardView: View {

    var revenue: Double {
        Transaction.sampleData
            .filter { $0.isRevenue }
            .reduce(0) { $0 + $1.amount }
    }

    var expenses: Double {
        Transaction.sampleData
            .filter { !$0.isRevenue }
            .reduce(0) { $0 + $1.amount }
    }

    var body: some View {
        ScrollView {

            //Revenue and Expense Overview
            
            VStack(alignment: .leading, spacing: 20) {

                Text("Dashboard")
                    .font(.largeTitle)
                    .bold()
                    .padding(.horizontal)

                HStack(spacing: 12) {
                    KPIBoxView(
                        title: "Revenue",
                        value: String(format: "$%.0f", revenue),
                        icon: "dollarsign.circle"
                    )

                    KPIBoxView(
                        title: "Expenses",
                        value: String(format: "$%.0f", expenses),
                        icon: "cart"
                    )
                }
                .padding(.horizontal)
                .padding(.horizontal)

                Text("Recent Transactions")
                    .font(.title2)
                    .bold()
                    .padding(.horizontal)
                
                //Recent Transactions List

                VStack {
                    ForEach(Transaction.sampleData.prefix(5)) { transaction in
                        TransactionRowView(transaction: transaction)
                        Divider()
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

#Preview {
    DashboardView()
}
