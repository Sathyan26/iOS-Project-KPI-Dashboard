//
//  ContentView.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {

            DashboardView()
                .tabItem {
                    Label("Dashboard", systemImage: "house")
                }

            AnalyticsView()
                .tabItem {
                    Label("Analytics", systemImage: "chart.bar")
                }
            
            CustomersView()
                .tabItem {
                    Label("Customers", systemImage: "person.3")
                }
            
            TransactionFormView()
                .tabItem {
                    Label("Add", systemImage: "plus.circle")
                }
        }
    }
}

#Preview {
    ContentView()
}
