//
//  BizInsightApp.swift
//  BizInsight
//
//  Created by Alexander Cumbo on 4/10/26.
//

import SwiftUI

@main
struct BizInsightApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
